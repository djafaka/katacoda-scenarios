You now know how to run containers based on images from official registry, expose ports and mount volumes.
