Dans ce scénario, vous vous familiariserez avec Docker CLI et déploierez vos premiers conteneurs !
