Pour vous assurer que Docker est disponible dans notre annonce système, obtenez un aperçu rapide de notre configuration Docker, exécutez simplement
`docker info`{{execute}}.

Pour obtenir des informations sur l'exécution des conteneurs, exécuter `docker ps`{{execute}} (la liste devrait être vide pour l'instant).

