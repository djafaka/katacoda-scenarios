echo "Dockerfile" > .dockerignore
