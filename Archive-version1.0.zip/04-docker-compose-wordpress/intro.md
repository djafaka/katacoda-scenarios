In this scenario you will try to dockerize WordPress using Docker-Compose.
