To stop your containers use `docker-compose stop`{{execute}}.

To remove the containers, images and networks, use `docker-compose down`{{execute}}.
