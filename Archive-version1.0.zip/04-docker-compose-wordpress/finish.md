You now know how to simply dockerize WordPress.
