If you want to handle more requests you may want to scale your app.
Try using `docker-compose up -d --scale wp=3`{{execute}} to scale your app.
Verify it by running `docker-compose ps`{{execute}}
