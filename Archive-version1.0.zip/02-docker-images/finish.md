You now know how to create your own images and run them.
