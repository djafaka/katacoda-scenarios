Let's not waste too much storage and remove obsolete images.
Use `docker rmi <image_name>` to remove image. You can use its ID or `name:tag`.

Run: `docker rmi mysql:latest`{{execute}} and `docker rmi mysql:8`{{execute}} to remove this image.
