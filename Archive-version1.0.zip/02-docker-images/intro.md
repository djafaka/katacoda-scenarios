In this scenario you will dockerize a simple Python app.
